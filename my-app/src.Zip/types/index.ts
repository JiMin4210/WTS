export type DeviceSummary = { deviceId: string; nickname: string };
export type Point = { x: string; y: number };
export type Tab = "day" | "month" | "year";
